
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc
 */
public class HRHeadLogin extends javax.swing.JFrame {

    /**
     * Creates new form UserLogin
     */
    public HRHeadLogin() {
        initComponents();
        setSize(1280,755);
        setResizable(false);
        setLocationRelativeTo(null);
    }

    public void LoginControl(){
       String username = usertf.getText();
       String pass = new String(passpf.getPassword());
       if(username.equals("")||pass.equals("")){
           JOptionPane.showMessageDialog(this, "Please enter both username and password");
       }else{
           try {
                ResultSet rs = DBLoader.executeStatement("select * from hrheadlogin where username='"+username+"'");
                if(rs.next()){
                     String dpass = rs.getString(2);
                     if(dpass.equals(pass)){
                         JOptionPane.showMessageDialog(this, "Login Successful");
                         this.dispose();
                         new HRHeadHome().setVisible(true);
                     }else{
                         JOptionPane.showMessageDialog(this, "The Password you have entered is wrong");
                     }
                }else{
                    JOptionPane.showMessageDialog(this, "User does not exist");
                }
           } catch (Exception e) {
               e.printStackTrace();
       }
       }
       
   }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        usertf = new javax.swing.JTextField();
        passpf = new javax.swing.JPasswordField();
        jLabel2 = new javax.swing.JLabel();
        submitlb = new javax.swing.JLabel();
        backlb = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        getContentPane().add(usertf);
        usertf.setBounds(500, 320, 280, 40);
        getContentPane().add(passpf);
        passpf.setBounds(490, 480, 290, 40);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Documents\\Classic conference presentation - png\\slide 6.png")); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 1280, 720);

        submitlb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                submitlbMouseClicked(evt);
            }
        });
        getContentPane().add(submitlb);
        submitlb.setBounds(520, 560, 260, 70);

        backlb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backlbMouseClicked(evt);
            }
        });
        getContentPane().add(backlb);
        backlb.setBounds(1120, 660, 150, 50);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void submitlbMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_submitlbMouseClicked
       LoginControl();
    }//GEN-LAST:event_submitlbMouseClicked

    private void backlbMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backlbMouseClicked
        new MainPage().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backlbMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UserLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UserLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UserLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HRHeadLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel backlb;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPasswordField passpf;
    private javax.swing.JLabel submitlb;
    private javax.swing.JTextField usertf;
    // End of variables declaration//GEN-END:variables
}
